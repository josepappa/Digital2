/*
 * CONCATENACION.h
 *
 * Created: 31/01/2026 18:41:22
 *  Author: rodro
 */ 


#ifndef CONCATENACION_H_
#define CONCATENACION_H_
#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdio.h>
void concatenacion(char caracter);
void caden(char* uni);



#endif /* CONCATENACION_H_ */